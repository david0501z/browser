# FlClash浏览器集成 - 快速构建指南

## 🎯 问题解决

你遇到的以下问题都已经解决：

1. ✅ **`target file lib/main.dart not found`** - 创建了完整的Flutter项目结构
2. ✅ **Android v1 embedding构建失败** - 配置了完整的Android项目文件
3. ✅ **依赖问题** - 移除了无效的performance_monitor依赖
4. ✅ **文件名大小写冲突** - 删除了重复的Bookmark.dart文件

## 📋 最新修复 (2025-11-06)

### 文件名冲突解决
- **问题**: 存在`Bookmark.dart`和`bookmark.dart`两个文件导致文件系统不识别
- **解决**: 删除重复的`Bookmark.dart`，保留`bookmark.dart`
- **文档**: 查看 `FILENAME_CONFLICT_FIX.md` 了解详情

## 📁 项目结构

```
flclash_browser_app/
├── lib/
│   ├── main.dart                 ✅ 应用入口文件（已创建）
│   ├── models/                   ✅ 数据模型
│   ├── services/                 ✅ 业务服务
│   ├── widgets/                  ✅ UI组件
│   ├── pages/                    ✅ 页面
│   ├── providers/                ✅ 状态管理
│   ├── utils/                    ✅ 工具类
│   ├── themes/                   ✅ 主题
│   └── data/                     ✅ 数据
├── android/                      ✅ Android配置
├── assets/                       ✅ 资源文件
├── pubspec.yaml                  ✅ 项目配置
└── README.md                     ✅ 项目文档
```

## 🚀 快速开始

### 1. 进入项目目录
```bash
cd flclash_browser_app
```

### 2. 安装依赖
```bash
flutter pub get
```

### 3. 检查项目
```bash
flutter doctor
```

### 4. 运行应用
```bash
# 连接Android设备后运行
flutter run

# 或者构建APK
flutter build apk
```

## 🔧 构建选项

### Debug版本（开发测试）
```bash
flutter build apk --debug
```

### Release版本（生产发布）
```bash
flutter build apk --release
```

### 特定架构优化
```bash
# ARM64 (现代设备)
flutter build apk --release --target-platform android-arm64

# ARM32 (老设备兼容)
flutter build apk --release --target-platform android-arm

# 通用版本 (所有设备)
flutter build apk --release
```

## 📱 功能特性

### ✅ 已实现功能
- **内置浏览器**: 基于flutter_inappwebview
- **多标签页管理**: 支持标签页切换、关闭、重新排序
- **书签系统**: 添加、编辑、分类管理书签
- **历史记录**: 完整的浏览历史和搜索功能
- **代理集成**: 与FlClash代理引擎集成
- **统一设置**: 浏览器和代理设置界面
- **主题切换**: 明暗主题支持
- **性能优化**: 内存管理、缓存策略
- **数据加密**: AES-256-GCM敏感数据保护

### 🎨 界面特色
- **Material Design 3**: 现代化UI设计
- **响应式布局**: 支持多种屏幕尺寸
- **流畅动画**: 页面切换和交互动画
- **底部导航**: 浏览器、书签、历史、设置

## 🛠️ 开发工具

### 推荐IDE
- **Android Studio**: 官方推荐，功能完整
- **VS Code**: 轻量级，插件丰富
- **IntelliJ IDEA**: 功能强大的Java/Kotlin开发

### 必备插件
- Flutter
- Dart
- Flutter Widget Inspector
- Git

## 🔍 故障排除

### 常见问题解决

**1. 依赖冲突**
```bash
flutter clean
flutter pub get
```

**2. 构建失败**
```bash
flutter clean
flutter pub upgrade
flutter build apk --release
```

**3. 设备连接问题**
```bash
flutter devices
adb devices  # 检查Android设备
```

**4. 权限问题**
确保AndroidManifest.xml包含必要权限：
- INTERNET
- ACCESS_NETWORK_STATE
- READ_EXTERNAL_STORAGE
- WRITE_EXTERNAL_STORAGE

## 📊 性能优化

### 构建优化
```bash
# 启用代码混淆
flutter build apk --release --obfuscate --split-debug-info=build/debug-info/

# 减少包大小
flutter build apk --release --tree-shake-icons --split-debug-info=build/debug-info/
```

### 应用优化
- 定期清理缓存
- 监控内存使用
- 优化图片资源
- 使用懒加载

## 🤖 GitHub Actions 自动化

### 快速使用GitHub Actions

#### 1. 文件解压和提交
```bash
# 手动触发步骤
1. 进入GitHub仓库 → Actions
2. 选择"解压文件并提交"工作流
3. 点击"Run workflow"
4. 填写参数:
   - 文件压缩包路径: uploads/my-files.zip
   - 解压目标路径: . (项目根目录)
   - 提交信息: "chore: 更新项目文件"
5. 点击运行
```

#### 2. 构建APK
```bash
# 自动构建 (推送到main分支)
git add .
git commit -m "feat: 添加新功能"
git push origin main
# → 自动触发构建

# 手动构建
1. 进入GitHub仓库 → Actions
2. 选择"构建APK"工作流
3. 点击"Run workflow"
4. 选择构建类型: debug 或 release
5. 点击运行
```

#### 3. 配置签名 (Release构建)
```bash
# 首次设置签名
1. 进入GitHub仓库 → Actions
2. 选择"配置Android签名"工作流
3. 点击"Run workflow"
4. 按照生成的指南配置GitHub Secrets:
   - KEYSTORE_FILE (base64编码的密钥库)
   - KEYSTORE_PASSWORD
   - KEY_ALIAS
   - KEY_PASSWORD
```

### 📁 GitHub Actions 文件结构
```
flclash_browser_app/
├── .github/workflows/
│   ├── extract-and-commit.yml    # 文件解压提交
│   ├── build-apk.yml             # APK构建
│   └── setup-signing.yml         # 签名配置
├── GITHUB_ACTIONS.md             # 详细使用指南
├── GITHUB_ACTIONS_FILES.md       # 文件清单
└── QUICK_START.md                # 本快速入门
```

### ⚡ 常用操作

#### 批量更新项目文件
1. 准备zip压缩包
2. 上传到 `uploads/` 目录
3. 运行"解压文件并提交"工作流
4. 填写: `uploads/your-file.zip` → `.` → 提交信息

#### 开发调试
1. 推送代码 → 自动构建Debug APK
2. 下载构建产物进行测试
3. 修复问题并重新提交

#### 发布版本
1. 合并所有功能到main分支
2. 运行"构建APK" → 选择"release"
3. 下载Release APK
4. 发布到应用商店

## 🎯 下一步

### 本地开发
1. **测试应用**: 在设备上运行并测试所有功能
2. **集成FlClash**: 确保与FlClash代理引擎正确集成
3. **性能调优**: 根据使用情况优化性能
4. **用户测试**: 收集用户反馈并改进

### GitHub Actions
1. **立即测试**: 运行一次Debug构建验证环境
2. **配置签名**: 设置Release构建所需的签名
3. **自定义**: 根据需要修改工作流配置
4. **监控**: 定期检查构建状态和成功率

## 📞 支持

如果遇到问题：
1. 查看 `README.md` 获取详细文档
2. 检查Flutter官方文档
3. 搜索相关问题解决方案

---

**🎉 恭喜！** 现在你可以成功构建和运行FlClash浏览器集成应用了！