# FlClash浏览器集成应用

这是一个集成了浏览器功能的FlClash代理客户端，支持在单个应用中完成代理配置和网页浏览。

## 功能特性

### 核心功能
- 🌐 **内置浏览器**: 基于flutter_inappwebview的高性能WebView
- 🔒 **代理集成**: 与FlClash代理引擎无缝集成
- 📱 **多标签页**: 支持多标签浏览，标签页管理
- 🔖 **书签管理**: 书签添加、编辑、分类管理
- 📜 **历史记录**: 完整的浏览历史记录和搜索功能
- ⚙️ **统一设置**: 集成浏览器和代理设置界面

### 高级功能
- 🎨 **响应式设计**: 支持多种屏幕尺寸和设备
- 🌙 **主题切换**: 支持明暗主题模式
- 🔐 **数据加密**: 敏感数据AES-256-GCM加密存储
- 📊 **性能监控**: 实时性能监控和优化
- 🛡️ **隐私保护**: GDPR合规的数据处理
- 🚀 **性能优化**: 内存管理、缓存策略、后台冻结

## 项目结构

```
flclash_browser_app/
├── lib/
│   ├── main.dart                 # 应用入口
│   ├── models/                   # 数据模型
│   │   ├── BrowserTab.dart       # 浏览器标签页模型
│   │   ├── Bookmark.dart         # 书签模型
│   │   ├── HistoryEntry.dart     # 历史记录模型
│   │   └── BrowserSettings.dart  # 浏览器设置模型
│   ├── services/                 # 业务服务
│   │   ├── browser_ffi_service.dart    # FFI通信服务
│   │   ├── database_service.dart       # 数据库服务
│   │   ├── encryption_service.dart     # 加密服务
│   │   ├── settings_service.dart       # 设置服务
│   │   ├── traffic_monitor.dart        # 流量监控
│   │   └── performance_service.dart    # 性能服务
│   ├── widgets/                  # UI组件
│   │   ├── tab_manager.dart           # 标签页管理器
│   │   ├── browser_webview.dart       # WebView组件
│   │   ├── browser_toolbar.dart       # 浏览器工具栏
│   │   ├── bookmark_item.dart         # 书签项组件
│   │   └── history_item.dart          # 历史记录项组件
│   ├── pages/                    # 页面
│   │   ├── browser_page.dart          # 浏览器主页面
│   │   ├── bookmarks_page.dart        # 书签页面
│   │   ├── history_page.dart          # 历史记录页面
│   │   ├── unified_settings_page.dart # 统一设置页面
│   │   └── onboarding_page.dart       # 引导页面
│   ├── providers/                # 状态管理
│   │   ├── browser_providers.dart     # 浏览器状态
│   │   └── shared_state_provider.dart # 共享状态
│   ├── utils/                    # 工具类
│   │   ├── cache_manager.dart         # 缓存管理
│   │   ├── memory_manager.dart        # 内存管理
│   │   ├── proxy_validator.dart       # 代理验证
│   │   └── security_validator.dart    # 安全验证
│   ├── themes/                   # 主题
│   │   └── browser_theme.dart         # 浏览器主题
│   └── data/                     # 数据
│       └── help_content.dart          # 帮助内容
├── android/                      # Android配置
├── assets/                       # 资源文件
│   ├── images/                   # 图片资源
│   ├── icons/                    # 图标资源
│   └── fonts/                    # 字体文件
└── pubspec.yaml                  # 项目配置
```

## 安装和构建

### 环境要求
- Flutter SDK >= 3.0.0
- Dart SDK >= 3.0.0
- Android SDK (API 21+)
- Android Studio / VS Code

### 安装依赖
```bash
cd flclash_browser_app
flutter pub get
```

### 构建APK
```bash
# Debug版本
flutter build apk --debug

# Release版本
flutter build apk --release

# 特定架构
flutter build apk --release --target-platform android-arm64
```

### 运行应用
```bash
# 连接Android设备
flutter devices

# 运行应用
flutter run
```

## 配置说明

### 权限配置
应用需要以下权限：
- 网络权限 (Internet)
- 存储权限 (Storage)
- 通知权限 (Notification)
- 网络状态权限 (Network State)

### 代理集成
浏览器流量通过FFI接口与FlClash代理引擎集成：
- HTTP/HTTPS代理支持
- SOCKS5代理支持
- 自动代理配置
- 流量监控和统计

### 数据存储
- SQLite数据库存储书签和历史记录
- SharedPreferences存储应用设置
- AES-256-GCM加密敏感数据
- 自动数据备份和恢复

## 开发指南

### 添加新功能
1. 在对应目录创建文件
2. 更新pubspec.yaml添加依赖
3. 运行`flutter pub get`
4. 测试功能完整性

### 代码规范
- 使用Flutter/Dart官方代码规范
- 添加充分的注释和文档
- 遵循Material Design设计规范
- 实现响应式布局

### 测试
```bash
# 单元测试
flutter test

# 集成测试
flutter test integration_test/

# 代码覆盖率
flutter test --coverage
```

## 故障排除

### 常见问题

**1. 依赖冲突**
```bash
flutter clean
flutter pub get
```

**2. 构建失败**
```bash
flutter clean
flutter pub upgrade
flutter build apk
```

**3. 权限问题**
检查AndroidManifest.xml中的权限配置，确保所有必要权限都已声明。

**4. FFI集成问题**
确认Go后端库正确编译并放置在正确路径。

### 性能优化
- 定期清理缓存和历史记录
- 监控内存使用情况
- 优化图片和资源加载
- 使用懒加载策略

## 贡献指南

1. Fork项目
2. 创建功能分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 开启Pull Request

## 许可证

本项目基于MIT许可证开源。详情请查看LICENSE文件。

## 联系方式

如有问题或建议，请通过以下方式联系：
- 提交Issue
- 发送邮件
- 加入讨论群

---

**注意**: 本应用需要与FlClash主应用配合使用，确保FlClash代理引擎正常运行。