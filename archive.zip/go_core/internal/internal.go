package internal

// 内部包 - 包含 FlClash Go Core 的内部实现
// 这个包包含代理核心、流量监控和回调管理等核心功能