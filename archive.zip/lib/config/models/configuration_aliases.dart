/// 端口配置类 - PortSettings的别名
typedef PortConfiguration = PortSettings;

/// DNS配置类 - DNSSettings的别名
typedef DNSConfiguration = DNSSettings;