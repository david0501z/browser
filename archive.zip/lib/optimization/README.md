# 代理性能优化和内存管理系统

这是一个全面的Flutter性能优化和内存管理系统，提供多层次的性能监控、内存管理、资源优化和自动调优功能。

## 核心功能

### 🧠 内存管理器 (MemoryManager)
- **内存监控**: 实时监控内存使用情况，包括堆内存、缓存内存和系统内存
- **智能预警**: 基于内存使用率的预警系统，支持警告和严重级别预警
- **自动优化**: 垃圾回收、缓存清理、资源释放和内存压缩
- **趋势分析**: 内存使用趋势分析和优化建议
- **多平台支持**: Web、桌面和移动平台的内存监控实现

### 🖥️ CPU优化器 (CpuOptimizer)
- **CPU监控**: 实时监控CPU使用率、负载平均值和温度
- **性能优化**: 线程池优化、进程优先级调整、后台任务清理
- **智能限流**: 高负载时的自动CPU限流和节能模式
- **预警系统**: CPU使用率和温度预警机制
- **自适应调优**: 根据CPU负载自动调整系统行为

### 🔋 电池优化器 (BatteryOptimizer)
- **电池监控**: 实时监控电池电量、充电状态和温度
- **省电模式**: 自动启用省电模式以延长电池续航
- **智能优化**: 屏幕亮度调节、网络优化、视觉效果减少
- **温度保护**: 电池温度过高时的自动保护机制
- **充电优化**: 充电状态监控和优化建议

### 🗑️ 垃圾回收管理器 (GarbageCollectionManager)
- **GC监控**: 实时监控垃圾回收次数、时间和使用趋势
- **自动回收**: 手动触发垃圾回收和优化GC策略
- **内存优化**: 内存分配优化、对象清理和堆压缩
- **性能分析**: GC性能分析和优化建议
- **历史记录**: GC事件历史和统计分析

### 📊 性能分析器 (PerformanceProfiler)
- **帧率监控**: 实时监控帧时间、帧率和卡顿情况
- **性能指标**: CPU、内存、GPU、网络等综合性能分析
- **方法计时**: 自定义代码段的性能测量和分析
- **性能报告**: 详细的性能报告生成和优化建议
- **预警系统**: 性能异常的实时预警和通知

### 🔍 资源监控器 (ResourceMonitor)
- **综合监控**: CPU、内存、磁盘、网络、电池的统一监控
- **系统健康**: 系统健康状况评估和分级
- **资源优化**: 基于资源状态的智能优化策略
- **阈值管理**: 可配置的预警阈值和监控间隔
- **趋势分析**: 资源使用趋势和预测分析

### 🚀 代理性能优化器 (ProxyPerformanceOptimizer)
- **内存优化**: 自动垃圾回收、内存压缩、结构优化
- **网络优化**: 连接池管理、路径优化、DNS缓存
- **电池优化**: 省电模式、性能模式、自适应优化
- **CPU优化**: 优先级调整、并发控制、任务调度
- **自动调优**: 基于使用模式的智能调优

### 🌐 网络连接管理器 (NetworkConnectionManager)
- **连接池**: 高效的连接复用和管理
- **健康检查**: 自动检测和重建不健康连接
- **负载均衡**: 智能的连接分配
- **QoS支持**: 网络质量感知的服务质量
- **超时管理**: 智能的重试和超时策略

### 💾 缓存管理器 (CacheManager)
- **多级缓存**: 内存 → 磁盘 → 网络的层次化缓存
- **智能预加载**: 基于访问模式的数据预取
- **缓存压缩**: 自动压缩减少内存占用
- **LRU算法**: 最久未使用数据自动清理
- **缓存策略**: 灵活的缓存策略配置

### 📊 带宽监控器 (BandwidthMonitor)
- **实时监控**: 精确的流量统计和速率监控
- **网络质量评估**: 基于延迟和稳定性的质量评分
- **流量限制**: 智能的带宽控制和管理
- **预警系统**: 自动检测异常流量和使用率
- **优化建议**: 基于网络质量的优化建议

### 🎯 性能管理器 (PerformanceManager)
- **统一接口**: 集成所有优化组件的统一API
- **自动优化**: 智能的优化调度和执行
- **性能分析**: 综合性能分数和趋势分析
- **事件驱动**: 实时性能事件和状态通知
- **报告生成**: 自动生成详细的性能报告

## 快速开始

### 基础使用

#### 使用新性能优化组件

```dart
import 'package:flclash_browser_app/optimization/optimization_index.dart';

void main() async {
  // 初始化内存管理器
  final memoryManager = MemoryManager();
  final cpuOptimizer = CpuOptimizer();
  final batteryOptimizer = BatteryOptimizer();
  final gcManager = GarbageCollectionManager();
  final profiler = PerformanceProfiler();
  final resourceMonitor = ResourceMonitor();

  // 开始监控
  memoryManager.startMonitoring(intervalSeconds: 5);
  cpuOptimizer.startMonitoring(intervalSeconds: 2);
  batteryOptimizer.startMonitoring(intervalSeconds: 10);
  gcManager.startMonitoring(intervalSeconds: 5);
  profiler.startMonitoring(intervalSeconds: 1);
  resourceMonitor.startMonitoring(intervalSeconds: 3);

  // 设置回调函数
  memoryManager.onMemoryUsageChanged = (usage) {
    print('内存使用率: ${(usage * 100).toStringAsFixed(1)}%');
  };

  memoryManager.onMemoryAlert = (alert) {
    print('内存预警: ${alert.message}');
    if (alert.type == MemoryAlertType.critical) {
      // 立即执行内存优化
      memoryManager.performMemoryOptimization();
    }
  };

  cpuOptimizer.onCpuAlert = (alert) {
    print('CPU预警: ${alert.message}');
    if (alert.usagePercentage >= 0.9) {
      // 高负载时启用节能模式
      cpuOptimizer.performCpuOptimization();
    }
  };

  batteryOptimizer.onBatteryAlert = (alert) {
    print('电池预警: ${alert.message}');
    if (alert.type == BatteryAlertType.low) {
      // 低电量时启用省电模式
      batteryOptimizer.setPowerSavingMode(true);
    }
  };

  profiler.onPerformanceAlert = (alert) {
    print('性能预警: ${alert.message}');
    if (alert.type == PerformanceAlertType.jank) {
      // 卡顿时优化渲染性能
      profiler.performResourceOptimization();
    }
  };

  resourceMonitor.onResourceAlert = (alert) {
    print('资源预警: ${alert.message}');
  };

  // 定期获取性能报告
  Timer.periodic(Duration(minutes: 5), (timer) {
    final report = profiler.generatePerformanceReport();
    print('=== 性能报告 ===');
    print(report.summary);
    print('优化建议: ${report.suggestions.join(', ')}');
  });

  // 在应用结束时清理资源
  // AppLifeCycle disposing...
  memoryManager.dispose();
  cpuOptimizer.dispose();
  batteryOptimizer.dispose();
  gcManager.dispose();
  profiler.dispose();
  resourceMonitor.dispose();
}
```

#### 现有组件使用

```dart
import 'package:flclash_browser_app/optimization/index.dart';

void main() async {
  // 快速初始化优化系统
  final performanceManager = await initOptimizationSystem();
  
  // 使用缓存
  await performanceManager.setCache('user_data', {'name': '张三'});
  final userData = await performanceManager.getCache<Map<String, dynamic>>('user_data');
  
  // 执行网络请求
  final response = await performanceManager.executeNetworkRequest(
    host: 'example.com',
    method: 'GET',
    path: '/api/data',
  );
  
  // 查看性能统计
  print('性能分数: ${performanceManager.integratedStats.performanceScore}');
  
  // 清理资源
  await performanceManager.dispose();
}
```

### 高级配置

#### 新组件配置示例

```dart
void setupAdvancedOptimization() {
  // 内存管理器配置
  final memoryManager = MemoryManager();
  memoryManager.setThresholds(
    warning: 0.7,  // 70% 预警阈值
    critical: 0.9, // 90% 严重预警阈值
  );

  // CPU优化器配置
  final cpuOptimizer = CpuOptimizer();
  cpuOptimizer.setThresholds(
    warning: 0.8,  // 80% 预警阈值
    critical: 0.95, // 95% 严重预警阈值
  );

  // 电池优化器配置 - 针对移动设备
  final batteryOptimizer = BatteryOptimizer();
  // 电池优化器会自动根据电量启用省电模式

  // 性能分析器配置
  final profiler = PerformanceProfiler();
  // 性能分析器会自动监控帧率和性能指标

  // 资源监控器配置
  final resourceMonitor = ResourceMonitor();
  final config = ResourceMonitoringConfig(
    enableCpuMonitoring: true,
    enableMemoryMonitoring: true,
    enableDiskMonitoring: true,
    enableNetworkMonitoring: true,
    enableBatteryMonitoring: true,
    alertThreshold: 0.8,
    historySize: 200,
  );
  resourceMonitor.setMonitoringConfig(config);

  // 垃圾回收管理器配置
  final gcManager = GarbageCollectionManager();
  // 垃圾回收管理器会自动监控GC状态并执行优化
}
```

#### 现有组件高级配置

```dart
// 使用高性能配置
final config = createHighPerformanceConfig();
final performanceManager = PerformanceManager();
await performanceManager.initialize(config: config);

// 或创建自定义配置
final customConfig = PerformanceManagerConfig(
  optimizerConfig: PerformanceConfig(
    enableAutoOptimization: true,
    optimizationIntervalSeconds: 30,
    memoryThreshold: 75.0,
    maxConcurrentConnections: 15,
  ),
  cacheConfig: CacheConfig(
    enableMemoryCache: true,
    enableDiskCache: true,
    maxMemorySize: 200 * 1024 * 1024, // 200MB
    defaultExpiry: const Duration(hours: 48),
  ),
  bandwidthConfig: BandwidthConfig(
    monitoringInterval: const Duration(seconds: 3),
    enableAlerts: true,
  ),
  enableSmartScheduling: true,
  enableAutoCacheCleanup: true,
  enableIntelligentPreload: true,
);

final manager = PerformanceManager();
await manager.initialize(config: customConfig);
```

### 性能监控

```dart
// 监听性能事件
performanceManager.eventStream.listen((event) {
  switch (event.type) {
    case EventType.performanceIssue:
      print('性能问题: ${event.data}');
      break;
    case EventType.performanceReport:
      print('性能报告: ${event.data}');
      break;
  }
});

// 获取性能建议
final recommendations = performanceManager.getRecommendations();
for (final rec in recommendations) {
  print('${rec.title}: ${rec.description}');
}

// 导出性能数据
final performanceData = await performanceManager.exportPerformanceData();
```

## 配置预设

### 高性能配置
适用于高性能需求场景，最大化资源利用：
```dart
final highPerfConfig = createHighPerformanceConfig();
```

### 省电配置
适用于移动设备，优化电池使用：
```dart
final powerSavingConfig = createPowerSavingConfig();
```

### 默认配置
平衡性能和资源使用：
```dart
final defaultConfig = createDefaultConfig();
```

## 性能优化功能

### 内存优化
- 自动垃圾回收
- 内存压缩
- 结构优化
- 清理过期数据

### 网络优化
- 连接池管理
- 智能重连
- 路径优化
- DNS缓存

### 缓存优化
- 多级缓存
- 智能预加载
- LRU清理
- 数据压缩

### 电池优化
- 省电模式
- 性能模式
- 自适应调整
- 后台优化

## 监控指标

### 内存管理指标
- **内存使用率**: 当前内存使用百分比
- **内存峰值**: 历史最高内存使用量
- **内存趋势**: 内存使用上升/下降/稳定趋势
- **GC统计**: 垃圾回收次数、时间、频率

### CPU性能指标
- **CPU使用率**: 当前CPU使用百分比
- **CPU温度**: 处理器温度监控
- **负载平均值**: 系统负载情况
- **核心利用率**: 多核CPU各核心使用情况

### 电池状态指标
- **电量级别**: 当前电池电量百分比
- **充电状态**: 充电/放电/满电状态
- **电池温度**: 电池温度监控
- **续航时间**: 估算剩余使用时间

### 性能分析指标
- **帧时间**: 平均帧渲染时间
- **帧率**: 平均FPS和实时FPS
- **慢帧统计**: 慢帧和卡顿帧数量
- **GPU指标**: 绘制调用、三角形数量、纹理内存

### 网络质量指标
- **下载/上传速度**: 实时网络速率
- **延迟**: 网络延迟测量
- **丢包率**: 网络丢包情况
- **连接质量**: 网络连接稳定性

### 系统资源指标
- **综合评分**: 系统整体健康状况
- **资源趋势**: 各资源使用趋势分析
- **预警统计**: 预警事件统计
- **优化效果**: 优化操作效果评估

## 性能优化功能

### 内存优化
- **自动垃圾回收**: 智能触发垃圾回收机制
- **内存压缩**: 减少内存碎片和优化内存布局
- **缓存清理**: 清理过期和未使用的缓存数据
- **资源释放**: 自动释放未使用的系统资源
- **对象池管理**: 复用对象减少分配开销

### CPU优化
- **线程池调整**: 根据CPU核心数优化线程池
- **优先级管理**: 调整进程和线程优先级
- **任务调度**: 智能的任务调度和负载均衡
- **并发控制**: 控制并发任务数量避免过载
- **性能模式**: 性能模式/节能模式自动切换

### 电池优化
- **省电模式**: 自动启用省电功能
- **屏幕调节**: 智能调节屏幕亮度和刷新率
- **网络优化**: 减少后台网络活动和请求频率
- **后台优化**: 限制后台任务和同步操作
- **温度保护**: 电池温度过高时的保护机制

### 垃圾回收优化
- **GC策略调整**: 根据应用类型调整GC策略
- **内存分配优化**: 优化对象创建和分配模式
- **堆压缩**: 减少内存碎片提高分配效率
- **对象生命周期**: 优化对象创建和销毁时机
- **缓存管理**: 智能的缓存大小和清理策略

### 性能分析优化
- **渲染优化**: 优化UI渲染性能减少卡顿
- **动画优化**: 优化动画效果和过渡
- **布局优化**: 优化Widget布局和重绘
- **代码优化**: 性能热点代码的优化建议
- **资源优化**: 图片、字体等资源的优化

### 系统资源优化
- **磁盘优化**: 清理临时文件和优化存储
- **网络优化**: 智能缓存和请求优化
- **系统缓存**: 优化系统缓存策略
- **资源整合**: 整合和优化系统资源使用
- **碎片整理**: 定期进行系统碎片整理

## 最佳实践

### 1. 移动设备优化
- **启用电池优化器**: 针对移动设备重点优化电池使用
- **合理设置阈值**: 根据设备性能设置合适的预警阈值
- **监控电池温度**: 避免电池过热影响设备寿命
- **使用省电模式**: 电量低时自动启用省电功能

### 2. 桌面应用优化
- **启用全面监控**: 利用更强的硬件资源进行全面监控
- **优化CPU使用**: 利用多核CPU优势优化并发处理
- **内存管理优化**: 对大内存应用进行精细化内存管理
- **性能分析**: 重点关注渲染性能和用户体验

### 3. 服务器应用优化
- **资源优先级**: 高优先级资源管理和优化
- **垃圾回收优化**: 针对长时间运行优化GC策略
- **监控预警**: 设置合适的预警阈值避免系统过载
- **性能报告**: 定期生成性能报告分析系统瓶颈

### 4. 通用优化建议
- **选择合适配置**: 根据使用场景选择合适的优化配置
- **定期监控**: 建立定期监控和报告机制
- **预警处理**: 及时响应预警并执行相应优化
- **性能评估**: 定期评估优化效果并调整策略

### 5. 配置最佳实践
- **高性能需求**: 高性能配置适用于服务器或游戏应用
- **移动设备**: 省电配置适用于移动设备
- **平衡使用**: 默认配置适用于大多数场景
- **自定义配置**: 根据具体需求自定义优化参数

### 6. 监控策略
- **多维度监控**: 同时监控多个维度的性能指标
- **趋势分析**: 关注性能指标的变化趋势
- **预警机制**: 建立完善的预警和处理机制
- **数据留存**: 保留历史数据用于趋势分析

## 故障排除

### 常见问题

**Q: 性能分数持续很低怎么办？**
A: 检查内存使用、连接成功率和缓存命中率，根据建议进行针对性优化。

**Q: 缓存命中率很低？**
A: 调整缓存大小、检查过期时间策略、启用智能预加载。

**Q: 网络连接经常失败？**
A: 检查网络质量、重试策略、连接池配置。

**Q: 电池消耗过快？**
A: 启用省电配置、减少后台活动、优化网络请求。

### 调试信息

系统提供详细的日志输出和性能事件，便于问题诊断：

```dart
// 启用详细日志
final config = PerformanceManagerConfig(...);
// 日志会自动输出到console
```

## API参考

### 核心管理类

#### 性能优化和内存管理组件
- `MemoryManager`: 内存管理器和监控
- `CpuOptimizer`: CPU性能优化和监控
- `BatteryOptimizer`: 电池优化和电源管理
- `GarbageCollectionManager`: 垃圾回收监控和管理
- `PerformanceProfiler`: 性能分析和测量
- `ResourceMonitor`: 综合系统资源监控

#### 网络和代理组件
- `PerformanceManager`: 核心性能管理器
- `ProxyPerformanceOptimizer`: 代理性能优化器
- `NetworkConnectionManager`: 网络连接管理器
- `CacheManager`: 多级缓存管理器
- `BandwidthMonitor`: 带宽和流量监控

### 主要数据类

#### 监控数据类
- `MemoryInfo`: 内存使用信息
- `CpuInfo`: CPU性能信息
- `BatteryInfo`: 电池状态信息
- `SystemResource`: 系统综合资源信息

#### 预警和报告类
- `MemoryAlert/CpuAlert/BatteryAlert`: 各类预警信息
- `PerformanceAlert`: 性能预警信息
- `ResourceAlert`: 资源预警信息
- `PerformanceReport`: 性能分析报告
- `SystemHealthAssessment`: 系统健康评估

#### 指标和统计类
- `FrameMetrics`: 帧渲染指标
- `GcStatistics`: 垃圾回收统计
- `PerformanceMetrics`: 性能指标集合

### 配置类
- `ResourceMonitoringConfig`: 资源监控配置
- `PerformanceManagerConfig`: 性能管理器配置
- `CacheConfig`: 缓存配置
- `NetworkConfig`: 网络配置

### 工具函数和枚举
- `OptimizationUtils`: 优化工具函数
- 各类枚举: `AlertType`, `HealthLevel`, `ResourceCategory` 等

## 许可证

本项目采用MIT许可证。

## 贡献

欢迎提交问题和功能请求！